
Version 1.0.10

Mach-II is a framework for building robust, maintainable software.
The framework files (the files in the MachII directory) are not an 
application in themself (so browsing to index.cfm will not do anything), 
rather the framework is to be used as a toolkit. The index.cfm files
and other files in the root are meant to be used as templates in
applications you build.

To see the framework in action, please download one of the sample
apps available on www.mach-ii.com.

Mach-II uses absolute pathing for CFCs, so installation of both core 
framework files (the machii directory) and the sample applications 
is very important.

You should place the sample applications AND the framework code 
DIRECTLY under your web root. If your webroot is "wwwroot", your 
directory structure should look like this:

wwwroot
   +ContactManager
   +MachII
   +Roulette
   +ShoppingCart

To run a sample app, browse the index.cfm file located in the 
application root directory (of the sample app). 
For example, to run the Roulette application, 
open wwwroot/Roulette/index.cfm. 

If you encounter problems, please first ensure that your directory 
structure matches the one shown here. Next, try cycling the CFMX 
server. If problems persist, please email bugs@mach-ii.com.


Update notes:
1.0.1
-If you were experiencing a problem surrounding lastDateModified in 
the AppLoader (international users), the bug should be fixed.

1.0.2
-There were some changes made to some of the framework classes
that will affect the old ContactManager sample app.  Be sure to download
the new ContactManager sample app from the site.
-The mach-ii_1_0.dtd has been updated.
-The Mach-II Configuration Guide (pdf) has been included in a new
docs folder with the framework.

1.0.4
-Method configure() added to EventFilters, Listeners, and Plugins to 
avoid having to override the init() method of those components.
-Hint attribute for CFC declarations used to improve auto-generated 
documentation.

1.0.5
-IMPORTANT: <views>/<view> elements need to be changed to 
<views>/<page-view>. This change was made for DTD validation reasons. 
Consequently all the sample apps have been updated and should be 
redownloaded.
-Completed scope change of framework CFCs from this to variables.
-Added appManager as a argument to all framework managers' init() functions.
-Added get/setAppManager() functions to all framework managers.
-Added get/setAppManager() functions to Listener, EventFilter, Plugin.
-The mach-ii_1_0.dtd has been updated.
-The Mach-II Configuration Guide (pdf) has been updated and renamed.
-Attribute for version added to mach-ii.xml.

1.0.6
-IMPORTANT: <views>/<view> elements need to be changed to 
<page-views>/<page-view> and <event-handler>/<view> elements need
to be changed to <event-handler>/<view-page>. This change was made 
for DTD validation reasons. Consequently all the sample apps have 
been updated and should be 
redownloaded.
-The default mach-ii.cfm file has been updated to allow for multiple 
sub-apps.
-An exception will now be thrown if the maxEvents number of events is 
exceeded.
-Attribute for access (public|private) added to <event-handler> elements.
Private event-handlers cannot be accessed via the RequestHandler.
-Added functionality to support public/private event handling.
-Adjusted configuration lifecycle for framework managers. Each manager's
configure(), which calls each component's configure(), is now called 
after all the components are initialized.
-The mach-ii_1_0.dtd has been updated.
-The Mach-II Configuration Guide (pdf) has been updated.

1.0.7
-Fixed bug in ListenerManager and PluginManager where configure() was 
being called twice on all Listeners and Plugins.
-Fixed looping bug in RequestHandler.
-Events that caused exceptions are now set in the exception event under
key 'exceptionEvent'.
-The mach-ii.cfm file included with the framework code has been modified
so it can be included (and not have to be copied) for each application.
-Plugin point for exception handling added to base Plugin component.
-Added abortEvent() function to base Plugin component.
-Added get/setArgType() functions to MachII.framework.Event.
-Added removeArg() function to MachII.framework.Event.
-Created MachII.util.BeanUtil and added to core files.
-Created MachII.filters.EventBeanFilter and added to core files.
-Created MachII.framework.commands.EventBeanCommand and added to core files.
-<event-arg> element now has optional variable attribute to allow setting of
a variable (i.e. 'request.content') as an arg in an event.
-The mach-ii_1_0.dtd has been updated.
-The Mach-II Configuration Guide (pdf) has been updated.

1.0.8
-Thread safety issues fixed (using var declarations) in many of the core files.
-Tweaked error control in EventContext (handleException()) which also improves 
error control when an unknown event is announced from a listener.
-The Mach-II XLM Schema (xsd) has been included.

1.0.9
-Updated mach-ii.cfm file to make it thread/lock safe.
-Updated several core component method signatures (primarily to adjust access 
modifiers).
-PluginManager is now configured before the Listener/Filter/Event/View Managers.
-Updated EventContext to provide better access to processing details.
	-getNextEvent() now just peeks at the next event in the queue.
	-hasNextEvent() returns whether there is another event in the queue.
	-getPreviousEvent() returns a reference to the last event processed.
	-hasPreviousEvent() returns whether or not there is a previous event.
	-getNextEventInQueue() (private) dequeues the next event and returns it.
-Event's preInvoke()/postInvoke() methods removed (as well as calls to them 
from EventContext). These methods were never used.
-Improved whitespace output (added output="false" to all <cfcomponent>s).
-Fixed problems in mach-ii_1_0.dtd.
-Added peek() function to MachII.util.Queue.
-Event-mapping fixed to work with exception events.
-Exception handling wrapped in a try/catch so an exception thrown while 
Mach-II is handling an exception will rethrow the error.

1.0.10
-Created MachII.framework.BaseComponent. This component is the base 
for Listener, Plugin, and EventFilter.
-Added getProperty() and setProperty() method to BaseCompopnent. 
All components can access global configuration properties via getProperty() 
shortcut method.
-<view-page> element now has optional 'append' atribute for appending contentKey
values.
-Plugin execution occurs in order they were registered in configuration file.
-Added describeBean() function to MachII.util.BeanUtil.
-Updated mach-ii_1_0.dtd and mach-ii_1_0.xsd.
-The Mach-II Configuration Guide (pdf) has been updated.
-Fixed various bugs.
(Fixed: EventContext.hasPreviousEvent() threw exceptions.)
(Fixed: SimplePlugin had errorneous init() function.)
(Fixed: EventBeanCommand getters/setters made non-public.)
(Fixed: Type in EventManager method output attribute.)
