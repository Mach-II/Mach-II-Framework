-----------------------
Mach-II - Version 1.1.0
-----------------------
$Id: Mach-II-Readme.txt 517 2005-09-29 07:31:56Z pfarrell $

Mach-II is a framework for building robust, maintainable software.
Mach-II has been developed, tested, maintained, and used by an active 
community for over two years.

The framework files (the files in the MachII directory) are not an 
application in themself (so browsing to index.cfm will not do anything), 
rather the framework is to be used as a toolkit. The index.cfm files
and other files in the root are meant to be used as templates in
applications you build.

To see the framework in action, please download one of the sample
apps available from www.mach-ii.com or browse to 
http://(localhost:8500}/MachII/testInstall 
to test that Mach-II has been installed.

Mach-II uses absolute pathing for CFCs, so installation of both core 
framework files (the machii directory) and the sample applications 
is very important.

You should place the sample applications AND the framework code 
DIRECTLY under your web root. If your webroot is "wwwroot", your 
directory structure should look like this:

wwwroot
   +MachII
   +ContactManager
   +Roulette
   +ShoppingCart

To run a sample app, browse the index.cfm file located in the 
application root directory (of the sample app). 
For example, to run the Roulette application, 
open wwwroot/Roulette/index.cfm. 

If you encounter problems, please first ensure that your directory 
structure matches the one shown here. Next, try cycling the CFMX 
server. If problems persist, please email look for help on the Mach-II 
mailing list (subscribe by sending an email to 
mach-ii-coldfusion-subscribe@topica.com).

*** Special Installation Note ***
If you are updating your Mach-II installation from an older version, you
must recycle the CFMX server.  Otherwise, you will receive the following error:

The value returned from function getAppFactory() is not of type
MachII.framework.AppFactory.

The error occurred in *C:\...PathToYourWebRoot...\MachII\framework\AppLoader.cfc: line 65*
*Called from* C:\...PathToYourWebRoot...\MachII\mach-ii.cfm: line 55

-------------------------------
Update Notes for Version 1.1.0:
-------------------------------

- Fixed LSDatetimeParse() bug for non-EN locales. Now the framework uses a
different way of checking if the Mach-II configuration file has been changed.

- Fixed BaseComponent variables.propMgr. Fixed inconsistant implementation.
The propertyManager is now works with a getter/setter.

- Fixed BaseComponent.setProperty() bogus return bug.

- Fixed "White Screen Of Death" bug. Mach-II now throws an exception report if
the view does not exists instead of showing the "White Screen of Death".

- Changed mach-ii.cfm file to create a new AppLoader instance when reloading.
The AppLoader instance is initialized before being set in the application scope.

- Fixed AppFactory.createAppManager() passes configXML to appManager.init() bug.
This was a very old and completely harmless bug.

- Changed Exception object to hold original cfcatch data for better debugging.
Use getCaughtException() in the Exception object to dump the caught cfcatch data.

- Fixed Plugin.configure() executed in random order bug. The framework now
calls the plugin configure methods in the order they are defined in the Mach-II
configuration file.

- Changed PluginManger to use introspection on the plugin points. Only implemented
plugin points are now called on each request. This saves processing cycles when
the plugin point is not implemented in the plugin.

- Added Trace Plugin to show trace information. See header of file for more
information and details on how to use the new plugin.

- Changed framework to use better typed exceptions like
MachII.framework.ListenerAlreadyDefined, MachII.framework.PluginNotDefined, etc.

- Added PropertyManager getProperty() defaults. You can now set default values when
using getProperty().

- Added new listener invokers called EventInvoker and EventArgsInvokers to replace 
old ones.

- Specifying invokers for listeners is now optional (defaults to new EventInvoker).

- Added arguments resultArg and contentArg handling to <notify> and <view-page> 
elements respectively.

- Added ability to validate Mach-II (with detailed exception messages) by specifying 
new parameters to mach-ii.cfm.  This feature is only for CFMX 7+.  Refer to the 
Configuration Guide for more information.

- Added new <redirect> event-handler command.  Refer to the Configuration Guide for 
more information.

- Lots of other great things...
